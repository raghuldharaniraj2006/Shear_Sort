module row_sort(in_0,in_1,in_2,in_3,out0,out1,out2,out3);
input [7:0] in_0,in_1,in_2,in_3;

output reg [7:0]out0,out1,out2,out3;

//intermediate wires
reg [7:0] s_0,s_1,s_2,s_3;
reg [7:0] s1_0,s1_1,s1_2,s1_3;
reg [7:0] s2_0,s2_1,s2_2,s2_3;

always @ (in_1 or in_2 or in_3 or in_0 )
    begin
        //stage 0
       

        s_0 = (in_0 > in_1) ? in_1 : in_0;
        s_1 = (in_0 > in_1) ? in_0 : in_1;
        s_2 = (in_2 > in_3) ? in_3 : in_2;
        s_3 = (in_2 > in_3) ? in_2 : in_3;

        //stage 1
       

        s1_0 = (s_0 > s_2) ? s_2 : s_0;
        s1_1 = (s_0 > s_2) ? s_0 : s_2;
        s1_2 = (s_1 > s_3) ? s_3 : s_1;
        s1_3 = (s_1 > s_3) ? s_1 : s_3;

        //stage 2

     

        s2_0 = s1_0;
        s2_1 = (s1_1 > s1_2) ? s1_2 : s1_1;
        s2_2 = (s1_1 > s1_2) ? s1_1 : s1_2;
        s2_3 = s1_3;

        //sorted 
        out0 = s2_0;
        out1 = s2_1;
        out2 = s2_2;
        out3 = s2_3;

    end





endmodule
